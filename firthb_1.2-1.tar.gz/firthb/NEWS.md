# firthb 1.2-1 (2023-12-22)

- Some robust variance computational tools were modified.

# firthb 1.1-1 (2023-12-01)

- first version released on GitHub.

