# firthb 1.1-1 (2023-12-01)

- first version released on GitHub

