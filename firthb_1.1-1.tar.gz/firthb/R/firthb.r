firthb <- function(y, X, measure) {
    if (measure == "RR") {
        model <- mpoisson(y, X)
    } else if (measure == "RD") {
        model <- mlinear(y, X)
    } else {
        stop("Invalid measure. Please choose 'RR' or 'RD'.")
    }
    return(model)
}

mpoisson <- function(y, X) {
    n <- nrow(X)
    dim <- ncol(X)
    beta <- rep(0, dim) #beta initial values for iteration
    
    beta_glm_poisson <- rep(0, dim) 
    beta_firth_poisson <- rep(0, dim) 
    
    #GLM
    tol<-2
    while (tol > .0001){
        tryCatch({
            eta <- X %*% beta_glm_poisson
            mu <- as.vector(exp(eta))
            W <- diag(mu)
            W_root <- W^.5
            XW <- t(X) %*% W_root
            XWX <- solve(t(X) %*% W %*% X)
            Hmat <- t(XW) %*% XWX %*% XW
            U <- y - mu #no penalization
            Ustar <- t(X) %*% U
            delta <- as.vector(XWX %*% Ustar)
            beta_glm_poisson <- beta_glm_poisson + delta
            tol <- max(abs(delta))
        }, error = function(e) {
            beta_glm_poisson <- rep(NA, length(beta_firth_poisson))
            tol <- 0  # exit loop
        })
    }
    
    # Calculate the robust sandwich variance
    tryCatch({
        muhat <- as.vector(X %*% beta_glm_poisson)
        W <- diag(exp(muhat))
        V <- solve(t(X) %*% W %*% X)
        U <- diag(as.vector(y - muhat))
        #robust variance
        vcov_robust <- V %*% t(X) %*% (n/(n-length(beta_glm_poisson))*t(U)) %*% U %*% X %*% V # correction for finite sample
        robustse <- sqrt(diag(vcov_robust ))
    }, error = function(e) {
        robustse <- rep(NA, length(robustse))
    })
    
    cil_glm <- exp(beta_glm_poisson - qnorm(0.975) * robustse)
    ciu_glm <- exp(beta_glm_poisson + qnorm(0.975) * robustse)
    #beta_glm <- beta_glm_poisson
    
    #Firth
    tol<-2
    while (tol > .0001){
        tryCatch({
            eta <- X %*% beta_firth_poisson
            mu <- as.vector(exp(eta))
            W <- diag(mu)
            W_root <- W^.5
            XW <- t(X) %*% W_root
            XWX <- solve(t(X) %*% W %*% X)
            Hmat <- t(XW) %*% XWX %*% XW
            unit <- rep(1, nrow(X))
            U <- y - mu +  .5 * diag(diag(Hmat)) %*% unit  #with penalization
            Ustar <- t(X)%*% U
            delta <- as.vector(XWX %*% Ustar)
            beta_firth_poisson <- beta_firth_poisson + delta
            tol <- max(abs(delta))
        }, error = function(e) {
            beta_firth_poisson <- rep(NA, length(beta_firth_poisson))
            tol <- 0  # exit loop
        })
    }   
    
    # Calculate the robust sandwich variance
    tryCatch({
        muhat <- as.vector(X %*% beta_firth_poisson)
        W <- diag(exp(muhat))
        V <- solve(t(X) %*% W %*% X)
        U <- diag(as.vector(y - muhat))
        #robust variance
        vcov_robust <- V %*% t(X) %*% (n/(n-length(beta_firth_poisson))*t(U)) %*% U %*% X %*% V 
        
        # correction for finite sample
        #Morel's small sample bias correction
        V2 <- V %*% t(X) %*% (n/(n-length(beta_firth_poisson))*t(U)) %*% U %*% X
        kappa <- max(1,sum(diag(V2))/length(beta_firth_poisson))
        delta <- min(0.5,length(beta_firth_poisson)/(n-length(beta_firth_poisson)))
        vcov_morel <- vcov_robust + kappa*delta*V
        robustse <- sqrt(diag(vcov_robust ))
        morelse <- sqrt(diag(vcov_morel ))
    }, error = function(e) {
        robustse <- rep(NA, length(robustse))
        morelse <- rep(NA, length(morelse))
    })  
    cil_firth <- exp(beta_firth_poisson - qnorm(0.975) * robustse)
    ciu_firth <- exp(beta_firth_poisson + qnorm(0.975) * robustse)
    
    cil_morel <- exp(beta_firth_poisson - qnorm(0.975) * morelse)
    ciu_morel <- exp(beta_firth_poisson + qnorm(0.975) * morelse)
    
    glm_out <- data.frame(EstimatedRR = exp(beta_glm_poisson), Low95pctCI = cil_glm, Upp95pctCI = ciu_glm)
    firth_out <- data.frame(EstimatedRR = exp(beta_firth_poisson), Low95pctCI = cil_firth, Upp95pctCI = ciu_firth)
    morel_out <- data.frame(EstimatedRR = exp(beta_firth_poisson), Low95pctCI = cil_morel, Upp95pctCI = ciu_morel)
    return(list(glm = glm_out, firth = firth_out, morel = morel_out))
}


mlinear <- function(y, X) {
    n <- nrow(X)
    dim <- ncol(X)
    beta_glm_linear <- rep(0, dim) 
    beta_firth_linear <- rep(0, dim) 
    
    #GLM
    tol<-2
    while (tol > .0001){
        eta <- X %*% beta_glm_linear
        mu <- eta
        W <- diag(rep(1, nrow(X)))
        W_root <- W^.5
        XW <- t(X) %*% W_root
        XWX <- solve(t(X) %*% W %*% X)
        Hmat <- t(XW) %*% XWX %*% XW
        U <- y - mu #+ .5 * diag(diag(Hmat)) #no penalization
        Ustar <- t(X) %*% U
        delta <- as.vector(XWX %*% Ustar)
        beta_glm_linear <- beta_glm_linear + delta
        tol <- max(abs(delta))
    }
    
    # Calculate the robust sandwich variance
    muhat <- X %*% beta_glm_linear
    W <- diag(rep(1, nrow(X)))
    V <- solve(t(X) %*% W %*% X)
    U <- diag(as.vector(y - muhat))
    #robust variance
    vcov_robust <- V %*% t(X) %*% (n/(n-length(beta_glm_linear))*t(U)) %*% U %*% X %*% V # correction for finite sample
    robustse <- sqrt(diag(vcov_robust ))
    
    cil_glm <- beta_glm_linear - qnorm(0.975) * robustse
    ciu_glm <- beta_glm_linear + qnorm(0.975) * robustse
    
    #Firth
    tol<-2
    while (tol > .0001){
        eta <- X %*% beta_firth_linear
        mu <- as.vector(eta)
        W <- diag(rep(1, nrow(X)))
        W_root <- W^.5
        XW <- t(X) %*% W_root
        XWX <- solve(t(X) %*% W %*% X)
        Hmat <- t(XW) %*% XWX %*% XW
        unit <- rep(1, nrow(X))
        U <- y - mu #+  .5 * diag(diag(Hmat)) %*% unit  #with penalization but its ignorable
        Ustar <- t(X)%*% U
        delta <- as.vector(XWX %*% Ustar)
        beta_firth_linear <- beta_firth_linear + delta
        tol <- max(abs(delta))
    }   
    
    # Calculate the robust sandwich variance
    muhat <- X %*% beta_firth_linear
    W <- diag(rep(1, nrow(X)))
    V <- solve(t(X) %*% W %*% X)
    U <- diag(as.vector(y - muhat))
    #robust variance
    vcov_robust <- V %*% t(X) %*% (n/(n-length(beta_firth_linear))*t(U)) %*% U %*% X %*% V 
    
    # correction for finite sample
    #Morel's small sample bias correction
    V2 <- V %*% t(X) %*% (n/(n-length(beta_firth_linear))*t(U)) %*% U %*% X
    kappa <- max(1,sum(diag(V2))/length(beta_firth_linear))
    delta <- min(0.5,length(beta_firth_linear)/(n-length(beta_firth_linear)))
    vcov_morel <- vcov_robust + kappa*delta*V
    robustse <- sqrt(diag(vcov_robust ))
    morelse <- sqrt(diag(vcov_morel ))
    
    cil_firth <- beta_firth_linear - qnorm(0.975) * robustse
    ciu_firth <- beta_firth_linear + qnorm(0.975) * robustse

    cil_morel <- beta_firth_linear - qnorm(0.975) * morelse
    ciu_morel <- beta_firth_linear + qnorm(0.975) * morelse
    
    glm_out <- data.frame(EstimatedRD = beta_glm_linear, Low95pctCI = cil_glm, Upp95pctCI = ciu_glm)
    firth_out <- data.frame(EstimatedRD = beta_firth_linear, Low95pctCI = cil_firth, Upp95pctCI = ciu_firth)
    morel_out <- data.frame(EstimatedRD = beta_firth_linear, Low95pctCI = cil_morel, Upp95pctCI = ciu_morel)
    return(list(glm = glm_out, firth = firth_out, morel = morel_out))
}
