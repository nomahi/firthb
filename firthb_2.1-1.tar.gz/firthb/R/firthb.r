firthb <- function(formula, data, measure) {

	if(measure=="RR"){
		gm1 <- glm(formula, data=data, family = poisson, x=TRUE)
	}
	if(measure=="RD"){
		gm1 <- glm(formula, data=data, family = gaussian, x=TRUE)
	}
	y <- gm1$y		# 結果変数ベクトル
	X <- gm1$x		# 説明変数行列
    if (measure == "RR") {
        model <- mpoisson(y, X)
    } else if (measure == "RD") {
        model <- mlinear(y, X)
    } else {
        stop("Invalid measure type. Choose 'RR' or 'RD'.")
    }
    return(model)
}

#function for matrix calculation for covariance estimation in modified Poisson regression
calc_mat_p <- function(X, y, b, R) {
    mu <- c(exp( X %*% b)) 
    nu <- mu  
    e <- y - mu
    D <- nu * X
    Vinv <- sqrt(1 / nu) * ginv(R) * rep(sqrt(1 / nu), each = length(y)) 
    
    list(mu = mu, nu = nu, D = D,
         Vinv = Vinv, VD = Vinv %*% D,
         e = e, emat = tcrossprod(e))
}

#function for matrix calculation for covariance estimation in least squares regression
calc_mat_l <- function(X, y, b, R) {
    mu <- c(X %*% b) 
    nu <- 1  
    e <- y - mu
    D <- nu * X
    Vinv <- sqrt(1 / nu) * ginv(R) * rep(sqrt(1 / nu), each = length(y)) 
    
    list(mu = mu, nu = nu, D = D,
         Vinv = Vinv, VD = Vinv %*% D,
         e = e, emat = tcrossprod(e))
}


mpoisson <- function(y, X) {
    p <- ncol(X)
    idseq <- 1:nrow(X)
    repseq <- rep(1, nrow(X))
    n <- length(unique(repseq))
    K <- length(unique(idseq))
    ndat <- as.numeric(table(idseq))
    replst <- split(repseq, idseq)
    
    beta_glm_poisson <- rep(0, p) 
    beta_firth_poisson <- rep(0, p) 
    ############################################################################
    #GLM
    b <- numeric(p)
    del <- 100
    nitr <- 0
    while (del > 1e-5) {
        mu <- exp(X %*% b) 
        I <- t(c(mu) * X) %*% X 
        U <- t(X) %*%(y - mu) 
        del <- max(abs(U))
        if (del > 1e-5) b <- b + ginv(I) %*% U
        nitr <- nitr + 1
        if (nitr == 50) break
    }
    
    nitr <- 0
    del <- 100
    while (del > 1e-5) {
        mu <- exp(X %*% b) 
        r <- (y - mu) / sqrt(mu) 
        if (min(mu) <= 0) { 
            conv <- "fitted probabilities numerically 0 occurred." 
            warning(conv)
            break
        }
        
        R <- diag(n) #fix in independence setting for non-repeated data 
        U <- numeric(p)
        I <- matrix(0, p, p)
        dI <- array(0, c(p, p, p))
        for (i in 1:K) {
            mat <- calc_mat_p(X[idseq == i, , drop = FALSE], y[idseq == i], b,
                              R[replst[[i]], replst[[i]]])
            U <- U + t(mat$VD) %*% mat$e
            I <- I + t(mat$D) %*% mat$VD
        }
        
        Iinv <- ginv(I)
        del <- max(abs(U))
        if (del > 1e-5) b <- b + Iinv %*% U
        nitr <- nitr + 1
        if (nitr == 50) {
            if (del > 1e-5) conv <- "maximum number of iterations consumed"
            warning(conv)
            break
        }
    }

        # Calculate the robust sandwich variance
    J <- matrix(0, p, p)
        for (i in 1:K) {
            mat <- calc_mat_p(X[idseq == i, , drop = FALSE], y[idseq == i], b,
                              R[replst[[i]], replst[[i]]])
            J <- J + t(mat$VD) %*% mat$emat %*% mat$VD
        }
    covb <- Iinv %*% J %*% Iinv
    
    #contain estimated results
    beta_glm_poisson <- b
    glm_se <- sqrt(diag(covb))
    cil_glm <- exp(beta_glm_poisson - qnorm(0.975) * glm_se)
    ciu_glm <- exp(beta_glm_poisson + qnorm(0.975) * glm_se)

    ########################################################################
    #Firth
    b <- numeric(p)
    del <- 100
    nitr <- 0
    while (del > 1e-5) {
        mu <- exp(X %*% b) 
        I <- t(c(mu) * X) %*% X 
        U <- t(X) %*%(y - mu + diag(X %*% ginv(I) %*% t(X)) * mu * 0.5) 
        del <- max(abs(U))
        if (del > 1e-5) b <- b + ginv(I) %*% U
        nitr <- nitr + 1
        if (nitr == 50) break
    }
    
    nitr <- 0
    del <- 100
    while (del > 1e-5) {
        mu <- exp(X %*% b) 
        r <- (y - mu) / sqrt(mu) 
        
        if (min(mu) <= 0) { 
            conv <- "fitted probabilities numerically 0 occurred." 
            warning(conv)
            break
        }
        
        R <- diag(n) #fix in independence setting for non-repeated data 
        U <- numeric(p)
        I <- matrix(0, p, p)
        dI <- array(0, c(p, p, p))
        for (i in 1:K) {
            mat <- calc_mat_p(X[idseq == i, , drop = FALSE], y[idseq == i], b,
                              R[replst[[i]], replst[[i]]])
            
            U <- U + t(mat$VD) %*% mat$e
            I <- I + t(mat$D) %*% mat$VD
            dI <- dI + array(apply(X[idseq == i, , drop = FALSE], 2, function (x) {
                t((c(1) * x) * mat$D) %*% mat$VD}) , c(p, p, p))
        }
     
        Iinv <- ginv(I)
        U <- U + 0.5 * apply(dI, 3, function (x) sum(diag(Iinv %*% x)))
        del <- max(abs(U))
        if (del > 1e-5) b <- b + Iinv %*% U
        nitr <- nitr + 1
        if (nitr == 50) {
            if (del > 1e-5) conv <- "maximum number of iterations consumed"
            warning(conv)
            break
        }
    }
    
    # Calculate the robust sandwich variance without Morel's bias correction
    J <- matrix(0, p, p)
    for (i in 1:K) {
        mat <- calc_mat_p(X[idseq == i, , drop = FALSE], y[idseq == i], b,
                          R[replst[[i]], replst[[i]]])
        J <- J + t(mat$VD) %*% mat$emat %*% mat$VD
    }
    
    covbf <- Iinv %*% J %*% Iinv
    
    #  Calculate the robust sandwich variance with Morel's bias correction
    J <- matrix(0, p, p)
    d <- matrix(0, K, p)
    for (i in 1:K) {
        mat <- calc_mat_p(X[idseq == i, , drop = FALSE], y[idseq == i], b,
                          R[replst[[i]], replst[[i]]])
        
        d[i, ] <- t(mat$VD) %*% mat$e
    }
    
    I1 <- (sum(ndat) - 1) * K * cov(d) / (sum(ndat) - p)
    q <- min(0.5, p / (K - p)) * max(1, sum(diag(Iinv %*% I1)) / p)
    J <- I1 + q * I
 
    covbm <- Iinv %*% J %*% Iinv

    #contain estimated results
    beta_firth_poisson <- b
    firth_se <- sqrt(diag(covbf))    
    morel_se <- sqrt(diag(covbm)) 
    
    cil_firth <- exp(beta_firth_poisson - qnorm(0.975) * firth_se)
    ciu_firth <- exp(beta_firth_poisson + qnorm(0.975) * firth_se)
    
    cil_morel <- exp(beta_firth_poisson - qnorm(0.975) * morel_se)
    ciu_morel <- exp(beta_firth_poisson + qnorm(0.975) * morel_se)
    
    glm_out <- data.frame(EstimatedRR = exp(beta_glm_poisson), Low95pctCI = cil_glm, Upp95pctCI = ciu_glm)
    firth_out <- data.frame(EstimatedRR = exp(beta_firth_poisson), Low95pctCI = cil_firth, Upp95pctCI = ciu_firth)
    morel_out <- data.frame(EstimatedRR = exp(beta_firth_poisson), Low95pctCI = cil_morel, Upp95pctCI = ciu_morel)
    return(list("glm+robust SE" = glm_out, "firth+robust SE" = firth_out, "firth+improved robust SE" = morel_out))
}


mlinear <- function(y, X) {
    p <- ncol(X)
    idseq <- 1:nrow(X)
    repseq <- rep(1, nrow(X))
    n <- length(unique(repseq))
    K <- length(unique(idseq))
    ndat <- as.numeric(table(idseq))
    replst <- split(repseq, idseq)
    
    beta_glm_poisson <- rep(0, p) 
    beta_firth_poisson <- rep(0, p) 
    ############################################################################
    #GLM
    b <- numeric(p)
    del <- 100
    nitr <- 0
    while (del > 1e-5) {
        mu <- X %*% b 
        I <- t(X) %*% X 
        U <- t(X) %*%(y - mu) 
        del <- max(abs(U))
        if (del > 1e-5) b <- b + ginv(I) %*% U
        nitr <- nitr + 1
        if (nitr == 50) break
    }
    
    nitr <- 0
    del <- 100
    while (del > 1e-5) {
        mu <- X %*% b 
        r <- (y - mu) / 1 
        R <- diag(n) #fix in independence setting for non-repeated data 
        U <- numeric(p)
        I <- matrix(0, p, p)
        dI <- array(0, c(p, p, p))
        for (i in 1:K) {
            mat <- calc_mat_l(X[idseq == i, , drop = FALSE], y[idseq == i], b,
                              R[replst[[i]], replst[[i]]])
            U <- U + t(mat$VD) %*% mat$e
            I <- I + t(mat$D) %*% mat$VD
        }
        
        Iinv <- ginv(I)
        del <- max(abs(U))
        if (del > 1e-5) b <- b + Iinv %*% U
        nitr <- nitr + 1
        if (nitr == 50) {
            if (del > 1e-5) conv <- "maximum number of iterations consumed"
            warning(conv)
            break
        }
    }
    
    
    # Calculate the robust sandwich variance
    J <- matrix(0, p, p)
    for (i in 1:K) {
        mat <- calc_mat_l(X[idseq == i, , drop = FALSE], y[idseq == i], b,
                          R[replst[[i]], replst[[i]]])
        J <- J + t(mat$VD) %*% mat$emat %*% mat$VD
    }
    covb <- Iinv %*% J %*% Iinv
    
    #contain estimated results
    beta_glm_linear <- b
    glm_se <- sqrt(diag(covb))
    cil_glm <- beta_glm_linear - qnorm(0.975) * glm_se
    ciu_glm <- beta_glm_linear + qnorm(0.975) * glm_se
    
    ########################################################################
    #Firth
    b <- numeric(p)
    del <- 100
    nitr <- 0
    while (del > 1e-5) {
        mu <- X %*% b 
        I <- t(X) %*% X 
        U <- t(X) %*%(y - mu + 0 * 0.5) 
        del <- max(abs(U))
        if (del > 1e-5) b <- b + ginv(I) %*% U
        nitr <- nitr + 1
        if (nitr == 50) break
    }
    
    nitr <- 0
    del <- 100
    while (del > 1e-5) {
        mu <- X %*% b 
        r <- (y - mu) / 1
        
        R <- diag(n) #fix in independence setting for non-repeated data 
        U <- numeric(p)
        I <- matrix(0, p, p)
        dI <- array(0, c(p, p, p))
        for (i in 1:K) {
            mat <- calc_mat_l(X[idseq == i, , drop = FALSE], y[idseq == i], b,
                              R[replst[[i]], replst[[i]]])
            
            U <- U + t(mat$VD) %*% mat$e
            I <- I + t(mat$D) %*% mat$VD
            dI <- dI + array(apply(X[idseq == i, , drop = FALSE], 2, function (x) {
                t((c(0) * x) * mat$D) %*% mat$VD}) , c(p, p, p))
        }
      
        Iinv <- ginv(I)
        U <- U 
        del <- max(abs(U))
        if (del > 1e-5) b <- b + Iinv %*% U
        nitr <- nitr + 1
        if (nitr == 50) {
            if (del > 1e-5) conv <- "maximum number of iterations consumed"
            warning(conv)
            break
        }
    }
    
    # Calculate the robust sandwich variance without Morel's bias correction
    J <- matrix(0, p, p)
    for (i in 1:K) {
        mat <- calc_mat_l(X[idseq == i, , drop = FALSE], y[idseq == i], b,
                          R[replst[[i]], replst[[i]]])
        J <- J + t(mat$VD) %*% mat$emat %*% mat$VD
    }
    
    covbf <- Iinv %*% J %*% Iinv
    
    #  Calculate the robust sandwich variance with Morel's bias correction
    J <- matrix(0, p, p)
    d <- matrix(0, K, p)
    for (i in 1:K) {
        mat <- calc_mat_l(X[idseq == i, , drop = FALSE], y[idseq == i], b,
                          R[replst[[i]], replst[[i]]])
        
        d[i, ] <- t(mat$VD) %*% mat$e
    }
    
    I1 <- (sum(ndat) - 1) * K * cov(d) / (sum(ndat) - p)
    q <- min(0.5, p / (K - p)) * max(1, sum(diag(Iinv %*% I1)) / p)
    J <- I1 + q * I
    
    covbm <- Iinv %*% J %*% Iinv
    #contain estimated results
    beta_firth_linear <- b
    firth_se <- sqrt(diag(covbf))    
    morel_se <- sqrt(diag(covbm)) 
    
    cil_firth <- beta_firth_linear - qnorm(0.975) * firth_se
    ciu_firth <- beta_firth_linear + qnorm(0.975) * firth_se
    
    cil_morel <- beta_firth_linear - qnorm(0.975) * morel_se
    ciu_morel <- beta_firth_linear + qnorm(0.975) * morel_se
    
    glm_out <- data.frame(EstimatedRD = beta_glm_linear, Low95pctCI = cil_glm, Upp95pctCI = ciu_glm)
    firth_out <- data.frame(EstimatedRD = beta_firth_linear, Low95pctCI = cil_firth, Upp95pctCI = ciu_firth)
    morel_out <- data.frame(EstimatedRD = beta_firth_linear, Low95pctCI = cil_morel, Upp95pctCI = ciu_morel)
    return(list("glm+robust SE" = glm_out, "firth+robust SE" = firth_out, "firth+improved robust SE" = morel_out))
}

