# firthb 2.2-1 (2023-12-27)

- Bibliographic information is updated.

# firthb 2.1-1 (2023-12-22)

- General syntax is changed.

# firthb 1.2-1 (2023-12-22)

- Some robust variance computational tools are modified.

# firthb 1.1-1 (2023-12-01)

- first version released on GitHub.

